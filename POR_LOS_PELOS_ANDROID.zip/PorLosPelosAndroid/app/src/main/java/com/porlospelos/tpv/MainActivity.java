package com.porlospelos.tpv;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidBridge(this, webView), "Android");
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    public static class AndroidBridge {
        private final Activity activity;
        private final WebView webView;
        AndroidBridge(Activity a, WebView w) { activity=a; webView=w; }
        @JavascriptInterface public void printTicket() {
            activity.runOnUiThread(() -> {
                PrintManager pm=(PrintManager)activity.getSystemService(Context.PRINT_SERVICE);
                String jobName="POR LOS PELOS - Ticket";
                pm.print(jobName, webView.createPrintDocumentAdapter(jobName),
                    new PrintAttributes.Builder()
                        .setMediaSize(PrintAttributes.MediaSize.NA_INDEX_3X5)
                        .setColorMode(PrintAttributes.COLOR_MODE_MONOCHROME)
                        .build());
            });
        }
        @JavascriptInterface public void toast(String msg) {
            activity.runOnUiThread(() -> Toast.makeText(activity,msg,Toast.LENGTH_SHORT).show());
        }
    }
}
